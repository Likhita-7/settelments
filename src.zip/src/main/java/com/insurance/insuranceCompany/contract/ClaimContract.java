package com.insurance.insuranceCompany.contract;

import java.text.ParseException;
import java.util.List;

import com.insurance.insuranceCompany.model.Claim;
import com.insurance.insuranceCompany.model.Claims;
import com.insurance.insuranceCompany.model.Settlements;

public interface ClaimContract {
	List<Claim> getApprovedClaims();

	Claims getClaimById(int claimId);

	void updatePayStatus(int claimId);

	void addPayment(int claimId);

	List<Settlements> getProcessedPayments();

	void addTransaction(int claim_id, String transId) throws ParseException, ParseException;

	
}